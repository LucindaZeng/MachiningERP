/**
 * 业务部数据分析六大类报表 mock 数据。
 * 每张表的口径写在页面卡片副标题中，来源单据见页面底部「指标口径与数据来源」。
 */

/* ---------------- 一、报价类 ---------------- */

export interface FunnelRow {
  stage: string
  count: number
  hint: string
}

export interface QuoteByDim {
  name: string
  quoted: number
  won: number
  rate: number
  avgMargin: number
}

export interface LostReason {
  reason: string
  count: number
  amount: number
}

export interface QuoteCycleRow {
  docNo: string
  customer: string
  costingHours: number
  approvalHours: number
  totalHours: number
  slaHours: number
  overdue: boolean
}

export interface CostVarianceRow {
  productName: string
  drawingNo: string
  quotedCost: string
  actualCost: string
  gapRate: number
  mainReason: string
}

/* ---------------- 二、订单类 ---------------- */

export interface BacklogRow {
  bucket: string
  orders: number
  amount: number
  hint: string
}

export interface OrderMixRow {
  type: string
  count: number
  amount: number
  share: number
}

export interface OrderTrendRow {
  month: string
  amount: number
  count: number
  yoy: number
  mom: number
}

export interface OnTimeRow {
  customer: string
  total: number
  late: number
  rate: number
}

export interface LateReason {
  reason: string
  count: number
  share: number
}

/* ---------------- 三、客户类 ---------------- */

export interface CustomerRankRow {
  customer: string
  amount: number
  share: number
  cumShare: number
  grade: 'A' | 'B' | 'C'
}

export interface CustomerMarginRow {
  customer: string
  amount: number
  margin: number
  target: number
}

export interface CustomerActivityRow {
  customer: string
  lastOrderAt: string
  daysSince: number
  freqChange: number
  risk: 'normal' | 'watch' | 'churn'
}

export interface NewCustomerRow {
  customer: string
  firstOrderAt: string
  firstAmount: number
  source: string
}

export interface ArAgingRow {
  customer: string
  notDue: number
  d1to30: number
  d31to60: number
  d61to90: number
  over90: number
}

/* ---------------- 四、产品与工艺类 ---------------- */

export interface ProductMarginRow {
  productName: string
  drawingNo: string
  amount: number
  margin: number
  quotedMargin: number
}

export interface MixRow {
  name: string
  value: number
  share: number
  trend: string
}

export interface PriceTrendRow {
  productName: string
  drawingNo: string
  history: Array<{ date: string; price: number }>
  materialChange: number
  suggestion: string
}

/* ---------------- 五、出货与回款类 ---------------- */

export interface ShipmentAchieveRow {
  month: string
  planned: number
  actual: number
  rate: number
}

export interface InvoiceReceivableRow {
  docNo: string
  customer: string
  shippedAt: string
  amount: number
  invoiced: boolean
  received: boolean
  ageDays: number
}

/* ---------------- 六、质量与客诉类 ---------------- */

export interface RmaStatRow {
  reason: string
  batches: number
  quantity: number
  amount: number
  share: number
}

export interface RepeatIssueRow {
  customer: string
  productName: string
  times: number
  lastAt: string
  status: string
}

export interface SalesReports {
  quoteFunnel: FunnelRow[]
  quoteByOwner: QuoteByDim[]
  quoteByMaterial: QuoteByDim[]
  lostReasons: LostReason[]
  quoteCycle: QuoteCycleRow[]
  costVariance: CostVarianceRow[]
  backlog: BacklogRow[]
  orderMix: OrderMixRow[]
  sampleConversion: { samples: number; converted: number; rate: number; amount: number }
  orderTrend: OrderTrendRow[]
  onTime: OnTimeRow[]
  lateReasons: LateReason[]
  customerRank: CustomerRankRow[]
  customerMargin: CustomerMarginRow[]
  customerActivity: CustomerActivityRow[]
  newCustomers: NewCustomerRow[]
  arAging: ArAgingRow[]
  productMargin: ProductMarginRow[]
  materialMix: MixRow[]
  processMix: MixRow[]
  priceTrend: PriceTrendRow[]
  shipmentAchieve: ShipmentAchieveRow[]
  invoiceReceivable: InvoiceReceivableRow[]
  rmaStats: RmaStatRow[]
  repeatIssues: RepeatIssueRow[]
}

export const SALES_REPORTS: SalesReports = {
  quoteFunnel: [
    { stage: '询价登记', count: 128, hint: '近 90 天进入系统的客户询价' },
    { stage: '已核价', count: 111, hint: '完成成本分析并生成核价单' },
    { stage: '已报出', count: 96, hint: '报价审批通过并发送客户' },
    { stage: '客户确认', count: 52, hint: '客户书面或门户确认报价版本' },
    { stage: '转为订单', count: 44, hint: '整体转化率 34.4%' },
  ],
  quoteByOwner: [
    { name: '罗晓琳', quoted: 58, won: 27, rate: 0.466, avgMargin: 0.221 },
    { name: '陈志强', quoted: 38, won: 17, rate: 0.447, avgMargin: 0.284 },
  ],
  quoteByMaterial: [
    { name: '6061-T6 铝合金', quoted: 34, won: 18, rate: 0.529, avgMargin: 0.226 },
    { name: '7075-T651 铝合金', quoted: 16, won: 7, rate: 0.438, avgMargin: 0.302 },
    { name: '304 / 316L 不锈钢', quoted: 22, won: 9, rate: 0.409, avgMargin: 0.278 },
    { name: '45# 碳钢', quoted: 18, won: 8, rate: 0.444, avgMargin: 0.176 },
    { name: 'TC4 钛合金', quoted: 6, won: 2, rate: 0.333, avgMargin: 0.291 },
  ],
  lostReasons: [
    { reason: '价格高于竞争对手', count: 21, amount: 486.2 },
    { reason: '交期无法满足', count: 12, amount: 268.4 },
    { reason: '客户项目取消 / 延期', count: 9, amount: 154.0 },
    { reason: '工艺能力不匹配（无五轴 / 无特殊表处）', count: 6, amount: 96.8 },
    { reason: '报价超期失效', count: 4, amount: 62.4 },
  ],
  quoteCycle: [
    {
      docNo: 'QT-20260722-0031',
      customer: '香港宏晟精密',
      costingHours: 26,
      approvalHours: 31.5,
      totalHours: 63.8,
      slaHours: 48,
      overdue: true,
    },
    {
      docNo: 'QT-20260724-0038',
      customer: 'Brenner',
      costingHours: 18.4,
      approvalHours: 5.2,
      totalHours: 26.7,
      slaHours: 48,
      overdue: false,
    },
    {
      docNo: 'QT-20260727-0042',
      customer: '苏州明泰',
      costingHours: 20.5,
      approvalHours: 0,
      totalHours: 21.7,
      slaHours: 48,
      overdue: false,
    },
    {
      docNo: 'QT-20260718-0026',
      customer: 'Radex',
      costingHours: 31,
      approvalHours: 24.2,
      totalHours: 59.2,
      slaHours: 48,
      overdue: true,
    },
    {
      docNo: 'QT-20260519-0033',
      customer: '深圳兆丰医疗',
      costingHours: 42.6,
      approvalHours: 12.1,
      totalHours: 58.8,
      slaHours: 48,
      overdue: true,
    },
  ],
  costVariance: [
    {
      productName: '连接器外壳 CNC 件',
      drawingNo: 'HS-4471-A',
      quotedCost: '13.05',
      actualCost: '13.48',
      gapRate: 0.033,
      mainReason: 'CNC 单件工时 10min → 11.2min，走心机换刀频次高于估算',
    },
    {
      productName: '探头支架',
      drawingNo: 'RX-3390',
      quotedCost: '17.16',
      actualCost: '18.02',
      gapRate: 0.05,
      mainReason: '硬质阳极色差返工 2 次，委外二次加工与运费未计入报价',
    },
    {
      productName: '直线导轨安装座',
      drawingNo: 'MT-7719',
      quotedCost: '39.18',
      actualCost: '40.61',
      gapRate: 0.037,
      mainReason: '加工中心工时低估 2min/件，夹具分摊按 500 件但实投 300 件',
    },
    {
      productName: '液压阀体',
      drawingNo: 'BR-2208',
      quotedCost: '84.90',
      actualCost: '83.20',
      gapRate: -0.02,
      mainReason: '四轴一次装夹后工时下降，实际优于报价假设',
    },
    {
      productName: '手术器械夹持件',
      drawingNo: 'ZF-7710',
      quotedCost: '201.00',
      actualCost: '216.30',
      gapRate: 0.076,
      mainReason: '钛合金刀具寿命远低于铝件假设，刀具费严重低估',
    },
  ],
  backlog: [
    { bucket: '本周内交付', orders: 3, amount: 96.4, hint: '含 1 张已延期' },
    { bucket: '2 周内', orders: 5, amount: 184.2, hint: '' },
    { bucket: '1 个月内', orders: 8, amount: 342.6, hint: '' },
    { bucket: '1–2 个月', orders: 6, amount: 268.8, hint: '' },
    { bucket: '2 个月以上', orders: 4, amount: 152.0, hint: '含模具订单 2 张' },
  ],
  orderMix: [
    { type: '正式业务订单', count: 38, amount: 2317.4, share: 0.875 },
    { type: '模具订单', count: 6, amount: 231.8, share: 0.088 },
    { type: '样品订单', count: 14, amount: 99.5, share: 0.038 },
    { type: '备料订单', count: 5, amount: 186.0, share: 0.0 },
  ],
  sampleConversion: { samples: 14, converted: 8, rate: 0.571, amount: 412.6 },
  orderTrend: [
    { month: '2026-02', amount: 151.3, count: 16, yoy: 0.062, mom: -0.153 },
    { month: '2026-03', amount: 243.9, count: 28, yoy: 0.184, mom: 0.612 },
    { month: '2026-04', amount: 262.4, count: 30, yoy: 0.142, mom: 0.076 },
    { month: '2026-05', amount: 288.1, count: 33, yoy: 0.201, mom: 0.098 },
    { month: '2026-06', amount: 301.6, count: 35, yoy: 0.176, mom: 0.047 },
    { month: '2026-07', amount: 386.4, count: 41, yoy: 0.312, mom: 0.281 },
  ],
  onTime: [
    { customer: '香港宏晟精密', total: 14, late: 1, rate: 0.929 },
    { customer: 'Brenner Maschinenbau', total: 9, late: 0, rate: 1 },
    { customer: 'Radex Instruments', total: 11, late: 2, rate: 0.818 },
    { customer: '苏州明泰自动化', total: 8, late: 1, rate: 0.875 },
    { customer: '东莞德信电子', total: 6, late: 0, rate: 1 },
  ],
  lateReasons: [
    { reason: '生产排程冲突 / 设备占用', count: 2, share: 0.5 },
    { reason: '来料延迟', count: 1, share: 0.25 },
    { reason: '图纸变更（ECN）', count: 1, share: 0.25 },
  ],
  customerRank: [
    { customer: '香港宏晟精密', amount: 742.5, share: 0.28, cumShare: 0.28, grade: 'A' },
    { customer: 'Brenner Maschinenbau', amount: 518.3, share: 0.196, cumShare: 0.476, grade: 'A' },
    { customer: 'Radex Instruments', amount: 404.1, share: 0.153, cumShare: 0.629, grade: 'A' },
    { customer: '苏州明泰自动化', amount: 288.4, share: 0.109, cumShare: 0.738, grade: 'B' },
    { customer: '东莞德信电子', amount: 196.2, share: 0.074, cumShare: 0.812, grade: 'B' },
    { customer: '深圳兆丰医疗', amount: 142.8, share: 0.054, cumShare: 0.866, grade: 'C' },
    { customer: '其他 12 家', amount: 356.4, share: 0.134, cumShare: 1, grade: 'C' },
  ],
  customerMargin: [
    { customer: '香港宏晟精密', amount: 742.5, margin: 0.198, target: 0.25 },
    { customer: 'Brenner Maschinenbau', amount: 518.3, margin: 0.291, target: 0.26 },
    { customer: 'Radex Instruments', amount: 404.1, margin: 0.276, target: 0.26 },
    { customer: '苏州明泰自动化', amount: 288.4, margin: 0.121, target: 0.18 },
    { customer: '东莞德信电子', amount: 196.2, margin: 0.238, target: 0.22 },
  ],
  customerActivity: [
    { customer: '东莞德信电子', lastOrderAt: '2026-03-18', daysSince: 132, freqChange: -0.62, risk: 'churn' },
    { customer: '深圳兆丰医疗', lastOrderAt: '2026-05-22', daysSince: 67, freqChange: -0.35, risk: 'watch' },
    { customer: '苏州明泰自动化', lastOrderAt: '2026-07-27', daysSince: 1, freqChange: -0.12, risk: 'normal' },
    { customer: '宁波精工液压', lastOrderAt: '2026-02-09', daysSince: 169, freqChange: -0.78, risk: 'churn' },
  ],
  newCustomers: [
    { customer: '深圳兆丰医疗', firstOrderAt: '2025-10-29', firstAmount: 85.8, source: '展会 · 深圳机械展' },
    { customer: '广州瑞泰自动化', firstOrderAt: '2026-04-16', firstAmount: 32.4, source: '老客户转介绍' },
    { customer: '东莞锐博机电', firstOrderAt: '2026-07-26', firstAmount: 0, source: '网络询盘（待首单）' },
  ],
  arAging: [
    { customer: '香港宏晟精密', notDue: 742.5, d1to30: 0, d31to60: 0, d61to90: 0, over90: 0 },
    { customer: 'Brenner Maschinenbau', notDue: 318.0, d1to30: 0, d31to60: 0, d61to90: 0, over90: 0 },
    { customer: 'Radex Instruments', notDue: 204.1, d1to30: 0, d31to60: 0, d61to90: 0, over90: 0 },
    { customer: '苏州明泰自动化', notDue: 461.6, d1to30: 126.8, d31to60: 0, d61to90: 0, over90: 0 },
    { customer: '深圳兆丰医疗', notDue: 42.0, d1to30: 0, d31to60: 18.6, d61to90: 0, over90: 0 },
  ],
  productMargin: [
    { productName: '液压阀体', drawingNo: 'BR-2208', amount: 518.3, margin: 0.291, quotedMargin: 0.284 },
    { productName: '探头支架', drawingNo: 'RX-3390', amount: 404.1, margin: 0.276, quotedMargin: 0.311 },
    { productName: '连接器外壳 CNC 件', drawingNo: 'HS-4471-A', amount: 588.0, margin: 0.198, quotedMargin: 0.223 },
    { productName: '直线导轨安装座', drawingNo: 'MT-7719', amount: 231.0, margin: 0.121, quotedMargin: 0.152 },
    { productName: '手术器械夹持件', drawingNo: 'ZF-7710', amount: 85.8, margin: 0.166, quotedMargin: 0.297 },
  ],
  materialMix: [
    { name: '铝合金（6061 / 6063 / 7075）', value: 1284.6, share: 0.485, trend: '+6.2%' },
    { name: '不锈钢（304 / 316L）', value: 706.2, share: 0.267, trend: '+2.4%' },
    { name: '碳钢（45# 等）', value: 402.8, share: 0.152, trend: '-3.1%' },
    { name: '铜合金', value: 168.4, share: 0.064, trend: '+1.2%' },
    { name: '钛合金', value: 86.7, share: 0.032, trend: '+18.4%' },
  ],
  processMix: [
    { name: 'CNC 加工中心（三轴）', value: 4820, share: 0.42, trend: '+4.1%' },
    { name: 'CNC 走心 / 走刀', value: 3160, share: 0.275, trend: '+9.6%' },
    { name: '普通车床 / 数控车', value: 2140, share: 0.186, trend: '-2.2%' },
    { name: '四轴 / 五轴', value: 1360, share: 0.119, trend: '+31.5%' },
  ],
  priceTrend: [
    {
      productName: '连接器外壳 CNC 件',
      drawingNo: 'HS-4471-A',
      history: [
        { date: '2025-09', price: 17.6 },
        { date: '2026-03', price: 17.2 },
        { date: '2026-07', price: 16.8 },
      ],
      materialChange: 0.046,
      suggestion: '铝锭月涨 4.6% 而售价连续下调，建议下轮报价上调 3–5% 或改阶梯价',
    },
    {
      productName: '探头支架',
      drawingNo: 'RX-3390',
      history: [
        { date: '2025-11', price: 26.8 },
        { date: '2026-04', price: 29.6 },
        { date: '2026-07', price: 24.9 },
      ],
      materialChange: 0.068,
      suggestion: '7075 涨 6.8%，本轮为抢单降价，实际毛利已跌破目标，需重新核价',
    },
    {
      productName: '液压阀体',
      drawingNo: 'BR-2208',
      history: [
        { date: '2025-12', price: 96.4 },
        { date: '2026-06', price: 132.0 },
        { date: '2026-07', price: 118.5 },
      ],
      materialChange: 0.021,
      suggestion: '价格随数量阶梯波动，属正常区间',
    },
  ],
  shipmentAchieve: [
    { month: '2026-03', planned: 236.0, actual: 228.4, rate: 0.968 },
    { month: '2026-04', planned: 258.0, actual: 251.2, rate: 0.974 },
    { month: '2026-05', planned: 274.0, actual: 268.8, rate: 0.981 },
    { month: '2026-06', planned: 296.0, actual: 279.4, rate: 0.944 },
    { month: '2026-07', planned: 342.0, actual: 316.8, rate: 0.926 },
  ],
  invoiceReceivable: [
    {
      docNo: 'SHP-20260724-0061',
      customer: '香港宏晟精密',
      shippedAt: '2026-07-25',
      amount: 48.0,
      invoiced: false,
      received: false,
      ageDays: 6,
    },
    {
      docNo: 'SHP-20260727-0064',
      customer: 'Radex Instruments',
      shippedAt: '2026-07-28',
      amount: 26.5,
      invoiced: false,
      received: false,
      ageDays: 3,
    },
    {
      docNo: 'SHP-20260715-0051',
      customer: '苏州明泰自动化',
      shippedAt: '2026-07-15',
      amount: 92.4,
      invoiced: true,
      received: false,
      ageDays: 16,
    },
    {
      docNo: 'SHP-20260706-0046',
      customer: '苏州明泰自动化',
      shippedAt: '2026-07-06',
      amount: 31.8,
      invoiced: true,
      received: false,
      ageDays: 25,
    },
    {
      docNo: 'SHP-20260721-0058',
      customer: 'Brenner Maschinenbau',
      shippedAt: '2026-07-22',
      amount: 118.5,
      invoiced: true,
      received: true,
      ageDays: 9,
    },
  ],
  rmaStats: [
    { reason: '尺寸超差', batches: 5, quantity: 386, amount: 12.4, share: 0.42 },
    { reason: '表面处理不良（色差 / 起泡）', batches: 3, quantity: 168, amount: 6.8, share: 0.23 },
    { reason: '包装运输损伤', batches: 2, quantity: 96, amount: 3.4, share: 0.115 },
    { reason: '数量短少', batches: 2, quantity: 62, amount: 2.2, share: 0.075 },
    { reason: '客户变更 / 多余退回', batches: 3, quantity: 140, amount: 4.8, share: 0.16 },
  ],
  repeatIssues: [
    {
      customer: 'Radex Instruments',
      productName: '探头支架',
      times: 3,
      lastAt: '2026-07-28',
      status: '第 3 次表面处理色差，委外供应商责任待判定',
    },
    {
      customer: '苏州明泰自动化',
      productName: '导轨压板',
      times: 2,
      lastAt: '2026-07-26',
      status: '孔位尺寸连续两批超差，8D-26-0031 执行中',
    },
    {
      customer: '深圳兆丰医疗',
      productName: '手术器械夹持件',
      times: 2,
      lastAt: '2026-05-14',
      status: '钛合金毛刺问题已结案，需在报价中计入去毛刺工时',
    },
  ],
}
